#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl> 

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_6e37b61b(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_3ae363ae() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_0e426984(inout vec4 vertex) {
    f_6e37b61b(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_3ae363ae();
    }
    finalize();
}



void f_c16ac551() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_bfdb7c6a() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_898e771b(inout vec4 vertex) {
    f_6e37b61b(vertex);
    f_c16ac551();
    finalize();
}

void f_42984fa6(inout vec4 vertex) {
    f_6e37b61b(vertex);
    f_3ae363ae();
    f_bfdb7c6a();
    finalize();
}

void f_e2a18575(inout vec4 vertex) {
    f_6e37b61b(vertex);
    f_bfdb7c6a();
    f_c16ac551();
    finalize();
}

void f_9d9af0dc(inout vec4 vertex) {
    f_3ae363ae();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_6e37b61b(vertex);
    finalize();
}

void f_36ea91a6(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_c16ac551();
    f_6e37b61b(vertex);
    finalize();
}

void f_fd9a3329(inout vec4 vertex, float speed) {
    f_6e37b61b(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_54e5306c(inout vec4 vertex) {
    f_6e37b61b(vertex);
    f_3ae363ae();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {

    sphericalVertexDistance=fog_spherical_distance(Position);
    cylindricalVertexDistance=fog_cylindrical_distance(Position);
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);

    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_0e426984(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_3ae363ae();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_6e37b61b(vertex);
            f_3ae363ae();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_42984fa6(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_42984fa6(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_9d9af0dc(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_9d9af0dc(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_fd9a3329(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_54e5306c(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_898e771b(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_42984fa6(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_e2a18575(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_9d9af0dc(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_36ea91a6(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_fd9a3329(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_898e771b(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_42984fa6(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_e2a18575(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_9d9af0dc(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_36ea91a6(vertex);
        return;
    }
    

    
    f_6e37b61b(vertex);
    f_3ae363ae();
    finalize();
}